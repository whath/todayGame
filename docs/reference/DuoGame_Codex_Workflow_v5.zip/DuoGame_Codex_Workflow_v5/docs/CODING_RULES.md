# Coding Rules

1. TypeScript.
2. Player never reads physical key/button constants directly.
3. P1/P2 share one Player implementation.
4. Input, Player, Camera, Gameplay, UI, and Platform remain separated.
5. Do not add networking in v0.1.
6. Prefer Cocos built-ins before dependencies.
7. No unrelated refactors.
8. Root-cause bugs before fixing.
9. Update architecture/decisions/devlog when materially affected.
10. Windows is the primary validation platform.