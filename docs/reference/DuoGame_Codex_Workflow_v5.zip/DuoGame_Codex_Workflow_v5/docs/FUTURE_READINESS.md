# Future Readiness — v5

## Networking
Do not implement networking now.

Preserve:
- InputSource -> PlayerCommand separation
- clean Actor authority boundaries
- stable Content IDs
- Time abstraction
- Random abstraction
- serialization boundaries

Future network design depends heavily on the chosen genre:
- Fighting may need rollback/prediction.
- Racing may need vehicle/state reconciliation.
- Management may tolerate lower-frequency synchronization.
- Action games may prefer host-authoritative networking.

Therefore no generic Netcode is selected before genre lock.

## Camera
Keep camera behavior policy-driven.
Possible future policies:
- Shared group camera
- Fighting arena camera
- Vehicle follow
- Management/free camera
- Split screen
- Cinematic camera

## Genre packs
All specialized gameplay frameworks remain deferred until prototype evidence exists.
