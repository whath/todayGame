# Architecture

Initial target boundary:

```text
UI / Join
   |
InputManager -> PlayerInputSlot -> InputDevice
   |
PlayerController -> PlayerMovement / PlayerState
   |
Game World
   |
SharedCameraController
```

Platform-specific and future networking layers are intentionally not implemented in v0.1.
