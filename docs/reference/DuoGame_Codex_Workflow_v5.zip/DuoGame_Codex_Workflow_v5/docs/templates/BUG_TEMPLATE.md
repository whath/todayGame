# BUG
<short bug title>

## EXPECTED
<expected behavior>

## ACTUAL
<actual behavior>

## REPRODUCTION
1.
2.
3.

## EVIDENCE
<logs/screenshots/conditions if available>

## REQUIREMENT
Use the bug-root-cause workflow. Do not mask the issue with delay/retry/swallowed exceptions.

## OUTPUT
- Root Cause
- Fix
- Regression Risk
- Verification
