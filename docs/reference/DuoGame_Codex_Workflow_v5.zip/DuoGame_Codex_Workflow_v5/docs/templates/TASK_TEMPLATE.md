# TASK
<one scoped task>

## CONTEXT
Read:
- AGENTS.md
- <relevant docs only>

## GOAL
<observable outcome>

## REQUIREMENTS
1.
2.
3.

## NON-GOALS
- 
- 

## ACCEPTANCE
1.
2.
3.

## AFTER IMPLEMENTATION
1. Run relevant validation.
2. List changed files.
3. Explain architecture impact.
4. Update required docs.
5. Provide manual playtest steps.
6. Do not change unrelated code.
