## YYYY-MM-DD

### Goal

### Design Discussion

### Decision

### Codex Task

### Implementation

### Problems

### Root Cause

### Result

### Footage Markers

### Next
