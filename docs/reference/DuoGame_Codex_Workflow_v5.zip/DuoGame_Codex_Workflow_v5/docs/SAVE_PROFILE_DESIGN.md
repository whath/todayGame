# Save & Profile Design

## Namespaces
- Settings: user preferences
- Profile: permanent progression/statistics
- Run/Session: temporary current-session state

## Save pipeline

```text
Runtime -> Snapshot DTO -> Validate -> Serialize -> SaveStorage
```

Load pipeline:

```text
SaveStorage -> Deserialize -> Migrate -> Validate -> Snapshot -> Rebuild runtime
```

Never serialize Node/Component directly. Persistent content references use stable IDs.
