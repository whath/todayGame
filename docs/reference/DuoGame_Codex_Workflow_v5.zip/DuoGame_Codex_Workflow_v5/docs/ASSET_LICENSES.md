# Asset Licenses

Every production external asset must be recorded here.
