# Test Strategy

## Pure TypeScript
Good for settings/save migration, random, content registry, rules.

## Integration
Good for player join, scene flow, settings apply, save/load round-trip.

## Manual playtest
Required for local simultaneous input, hot-plug, camera feel, UI navigation, and gameplay feel.

## Developer labs
- InputLab
- CameraLab
- SettingsLab
- SaveLab

Do not ship developer labs in Release builds unless explicitly intended.
