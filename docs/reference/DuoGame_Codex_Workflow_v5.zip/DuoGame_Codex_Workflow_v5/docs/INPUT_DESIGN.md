# Input Design

Target relationship:

```text
Player
  -> PlayerInputSlot
      -> InputDevice
          -> KeyboardInputDevice / GamepadInputDevice
```

Required v0.1 combinations:
- Keyboard A + Keyboard B
- Keyboard + Gamepad
- Gamepad + Keyboard
- Gamepad 1 + Gamepad 2

Semantic actions initially:
- Move
- PrimaryAction
- SecondaryAction
- Interact
