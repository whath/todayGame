# Runtime Foundation

## Runtime services
- GameBootstrap
- AppStateService
- SceneFlowService
- LoadingService
- TimeService
- RandomService
- FeatureFlagService
- BuildInfo
- GameLogger

## Principle

```text
UI / Gameplay
      |
      v
SceneFlowService
      |
      v
TransitionRequest -> preload -> activate -> initialize -> enter state
```

Keep gameplay time separate from UI/unscaled time. Route gameplay randomness through a seeded service when randomness becomes part of gameplay.
