# Content System

## Minimal concepts
- ContentId
- ContentDefinition
- ContentRegistry
- ContentValidator

## Stable ID examples
- `character.player.default`
- `level.prototype.room_01`

Do not use display name, prefab filename, or list position as persistence identity.

Only add definition types needed by current prototypes.
