# Local Multiplayer Robustness — v0.4

## Purpose
Provide reliable two-player local runtime behavior without assuming co-op or competitive gameplay.

## Core responsibilities
- Player identity and presence
- Join / Leave / Reconnect
- Device ownership
- Relationship model
- Replaceable CameraPolicy
- Player visibility tracking
- Interaction arbitration
- Ownership / Claim
- Shared UI ownership
- Spawn / recovery safety
- Targeted feedback
- Keyboard ghosting verification
- Multiplayer soft-lock auditing

## Relationship is game-defined
Possible relationships:
- Cooperative
- Competitive
- Mixed
- Neutral
- Team-based

## Interaction policies
- Exclusive
- Shared
- Simultaneous
- Competitive
- Cooperative
- Queued

## Rule
The foundation provides mechanisms and policies. The selected genre decides behavior.
