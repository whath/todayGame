# Asset Catalog

Assets will be registered after approval and technical intake.
