# 3D Asset Pipeline

## Primary Sources
1. Quaternius — style anchor / complete stylized sets
2. Fab Free — high-quality supplements
3. itch.io Free — distinctive/specialized supplements

## Responsibilities

### User
- choose general style
- shortlist candidate packs
- approve/reject final assets

### Codex
- inspect license
- inspect formats
- unpack
- normalize naming
- check model scale/orientation
- process via Blender when needed
- inspect materials/textures
- generate/verify collision
- import to Cocos
- create Prefabs
- create ContentDefinitions
- register source/license metadata
- run validation

## Intake States

DISCOVERED -> SHORTLISTED -> LICENSE_CHECKED -> TECH_CHECKED -> APPROVED -> PROCESSED -> IN_GAME

## Suggested external directory

D:\GameAssets\
- 01_Inbox
- 02_Shortlisted
- 03_Approved
- 04_Processing
- 05_Ready
- 06_Archive

## Required records
- ASSET_CATALOG.md
- ASSET_LICENSES.md
- per-pack manifest

## Rule
Free download does not equal commercial permission.
Unclear licenses do not enter the production library.
