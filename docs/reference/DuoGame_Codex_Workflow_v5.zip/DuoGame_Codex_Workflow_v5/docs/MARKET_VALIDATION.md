# Market Validation — 2026-09-23

## Decisions
- Keep PC local co-op as the first implementation.
- Keep controller-first and semantic-input architecture.
- Strengthen player-to-player interaction/robustness.
- End generic mandatory foundation at Universal Gameplay Kernel.
- Force playable prototype validation after v0.5.
- Make Combat, Narrative, Mission, Roguelike and Management optional Gameplay Packs.
- Keep WeChat/Douyin as future distribution adapters, not PC-core constraints.

## Sources
- Video Game Insights — Rise of the Co-op Games
  https://vginsights.com/insights/article/rise-of-the-co-op-games
- Game Developer — What developers can learn from indie social co-op games
  https://www.gamedeveloper.com/design/what-developers-can-learn-from-the-indie-social-co-op-games-topping-the-steam-charts
- Steamworks — Remote Play Together
  https://partner.steamgames.com/doc/features/remoteplay
- Steam News — Steam Input/controller support update
  https://store.steampowered.com/news/posts/?enddate=1722274413&feed=steam_news
- Steamworks — Steam Input Devices
  https://partner.steamgames.com/doc/features/steam_controller/device
- Niko Partners — China games market 2025
  https://nikopartners.com/chinas-video-games-market-in-2025-a-50-billion-opportunity/
