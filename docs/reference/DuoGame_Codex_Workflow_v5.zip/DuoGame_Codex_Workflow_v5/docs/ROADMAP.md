# Roadmap — v5 Genre-Agnostic

## v0.1 — Local Multiplayer Foundation
- Input abstraction
- player slots
- reusable Actor/Player base
- dual-player movement
- device assignment
- shared-camera prototype
- controller hot plug
- 3D prototype room
- Windows build

## v0.2 — Core Services & Settings
- Settings
- Audio
- Localization
- Accessibility
- Pause
- Platform capabilities
- Diagnostics

## v0.3 — Runtime & Content
- Bootstrap / AppState
- SceneFlow
- Loading
- Save/Profile infrastructure
- Content IDs / Registry / Validation
- Asset lifecycle
- UI navigation
- Time / Random
- Build variants / Logger / Test labs

## v0.4 — Local Multiplayer Robustness
- Player Presence
- join / leave / reconnect
- relationship model
- replaceable camera policy
- interaction arbitration
- ownership / claims
- shared UI ownership
- spawn/recovery safety
- keyboard ghosting checks
- genre-neutral multiplayer soft-lock audit

## v0.5 — Universal Gameplay Kernel
- Actor
- Identity
- State
- Action lifecycle
- Interaction
- Ownership
- Relationship
- lightweight Tags
- Trigger / Condition / Action
- semantic Feedback

# MARKETABLE PROTOTYPE GATE
Create several greybox prototypes, potentially from different genres.

Examples:
- Fighting prototype
- Racing prototype
- Management prototype

Do not extend generic Core merely because a system might be useful later.

# GAME DIRECTION LOCK
Choose the actual game direction based on playability and product potential.

# GENRE PACKS
Add only the packs required by the selected direction.

# VERTICAL SLICE
Build one complete playable loop.

# FOUNDATION LOCK
Shift from framework construction to content production.
