# UI Navigation Foundation

## Goals
- keyboard/controller-friendly menus
- predictable Back/Cancel
- modal ownership
- input-glyph abstraction

## Layers
- Screen
- Overlay
- Modal
- Toast
- Debug

Only the top relevant layer should consume Back/Cancel.
