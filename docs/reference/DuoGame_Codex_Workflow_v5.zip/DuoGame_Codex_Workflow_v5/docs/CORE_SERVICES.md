# Core Services Design

## Goal
Provide reusable game-level services without coupling gameplay to platform details.

## Services
- GameBootstrap
- SceneFlowService
- SettingsService
- SaveService
- AudioService
- LocalizationService
- PlatformCapabilityService
- PauseService
- DiagnosticsService
- InputManager
- PlayerManager

## Dependency principle

```text
Gameplay
   ↓
Semantic Services / Interfaces
   ↓
Platform / Engine adapters
```

Gameplay must not directly:
- manipulate OS windows,
- read/write arbitrary files,
- read physical key codes,
- change global audio levels,
- branch on platform identifiers.
