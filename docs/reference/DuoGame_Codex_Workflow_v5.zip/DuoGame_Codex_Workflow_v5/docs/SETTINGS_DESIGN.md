# Settings Design

## Categories
- Display
- Graphics
- Audio
- Controls
- Gameplay
- Accessibility
- Language

## Core architecture

```text
SettingDefinition
      ↓
SettingsRegistry
      ↓
SettingsStore
      ↓
SettingsApplier
      ↓
Engine / Platform

SettingsPersistence
SettingsMigration
PlatformCapabilityService
SettingsMenu
```

## Required setting metadata
- stable id
- category
- default value
- scope
- value type
- apply mode
- validation/range/options
- platform capability
- description/localization key

## Apply modes
- live
- onApply
- restartRequired

## Initial setting candidates

### Display
- Display Mode
- VSync
- Frame Limit
- Brightness/Gamma
- UI Scale
- Resolution only when the Windows-native path is verified

### Audio
- Master
- Music
- SFX
- UI
- Mute When Unfocused

### Controls
- P1/P2 bindings
- vibration
- deadzone
- restore defaults

### Accessibility
- UI Scale
- Reduce Screen Shake
- Reduce Flashing
- Subtitles
- Subtitle Size
- Subtitle Background Opacity

## Safety
Risky display changes use timed confirmation and revert.
Malformed persisted values are validated/clamped/fallback to defaults.
Settings schema must be versioned.
