# Decisions

## D-001 — Windows First
Windows is the primary development, debugging, recording, and first playable platform.

## D-002 — Local Co-op First
v0.1 is single-machine local co-op. No networking.

## D-003 — Shared Screen
PC players share one camera. No split screen in the foundation.

## D-004 — Genre Deferred
Final genre, art direction, combat style, and monetization remain undecided until the foundation is playable.


## D-005 — 3D is fixed
The game world is built as a 3D project. UI may remain 2D overlay.

## D-006 — Local Multiplayer, not Local Co-op
The foundation supports two local players but does not assume cooperation. Competitive and mixed relationships remain possible.

## D-007 — Genre remains undecided
Do not hardcode narrative, combat, racing, management, fighting, progression, or other genre assumptions into Core.

## D-008 — Networking is deferred, architecture remains compatible
Do not build networking yet. Keep physical input separate from semantic player commands and gameplay authority boundaries clean.

## D-009 — Primary free asset sources
Use Quaternius, Fab free content, and itch.io free content as the main discovery pool. Every production asset must pass license and technical checks.
