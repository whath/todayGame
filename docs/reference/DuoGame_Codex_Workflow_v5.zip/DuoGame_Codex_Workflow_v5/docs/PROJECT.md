# Project

## Technology
- Engine: Cocos Creator 3.8.x
- Language: TypeScript
- Primary development platform: Windows
- World: 3D

## Product shape
- Two-player local multiplayer first.
- Same PC process.
- Shared screen is the initial default, but camera policy remains replaceable.
- P1/P2 may use keyboard or gamepad.
- Future networking remains possible but is not implemented now.

## Genre
Intentionally undecided.

Possible directions include:
- Fighting
- Racing
- Management
- Action
- Shooter
- Puzzle
- Sports
- Simulation
- Roguelike
- Narrative
- Hybrid

Do not treat co-op, linear story, combat or any specific genre as a permanent project constraint.

## Assets
Primary free-content sources:
- Quaternius
- Fab
- itch.io

The user selects visual direction and approves assets. Codex owns technical processing and integration.

## Mandatory generic foundation
Ends at v0.5 Universal Gameplay Kernel.
After v0.5, build playable genre prototypes before expanding specialized frameworks.
