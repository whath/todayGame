# DuoGame Codex Workflow v5

Current authoritative direction:

- 3D
- Windows-first
- two-player local multiplayer first
- future online-capable architecture
- final genre intentionally undecided
- no fixed linear narrative requirement
- genre-specific systems are optional packs after prototype validation
- main free 3D asset sources: Quaternius, Fab and itch.io
- user selects style/assets; Codex handles technical integration

Start with:
1. `GAME_DEV_CODEX_MASTER_PLAN.md`
2. `docs/DESIGN_PILLARS.md`
3. `docs/ROADMAP.md`
4. `docs/ASSET_PIPELINE.md`
