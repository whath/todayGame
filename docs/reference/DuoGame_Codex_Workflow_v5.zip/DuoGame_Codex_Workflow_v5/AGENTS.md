# DuoGame Project Instructions

## Project
- Engine: Cocos Creator 3.8.x.
- Language: TypeScript.
- Primary development platform: Windows PC.
- Current milestone: v0.1 Local Co-op Foundation.
- The game is local two-player single-machine co-op.
- P1 and P2 share one game world and one camera; no split screen.
- Each player may use keyboard or gamepad through an input abstraction.
- Final game genre, art direction, combat style, and monetization are intentionally undecided.

## Hard boundaries for v0.1
Do not add networking, mobile platform code, WeChat/Douyin integration, Steam SDK, accounts, backend services, enemies, weapons, skills, bosses, formal art, or monetization unless the user explicitly changes the milestone.

## Architecture rules
- Player code must never read physical key/button codes directly.
- Route input through PlayerInputSlot -> InputDevice.
- P1 and P2 must use the same Player prefab and gameplay implementation.
- Keep Player, Input, Camera, Gameplay, UI, and Platform concerns separated.
- Do not create separate Player1/Player2 business logic.
- Prefer Cocos built-ins before adding dependencies.
- Do not add a production dependency without a concrete need.
- Avoid speculative abstractions for future platforms.
- Make the smallest defensible change for the active task.
- Do not refactor unrelated code while implementing a scoped task.

## Working method
1. Read relevant docs before editing.
2. Map ownership and execution path first.
3. Delegate only when specialization materially improves quality or parallelism.
4. Use no more subagents than necessary; for v0.1, 3-4 concurrent agents is normally enough.
5. Implement one verifiable task at a time.
6. Validate what changed.
7. Provide manual playtest steps when runtime behavior changed.
8. Update architecture/decision/devlog docs when the task materially affects them.
9. Before a version tag, use QA and code-review gates.

## Bug policy
- Reproduce first.
- Identify root cause.
- Do not hide failures with arbitrary delays, retries, swallowed exceptions, or unrelated null guards.
- Report regression risk and verification.

## Documentation
Keep these current when relevant:
- docs/PROJECT.md
- docs/ARCHITECTURE.md
- docs/CODING_RULES.md
- docs/INPUT_DESIGN.md
- docs/DECISIONS.md
- docs/DEVLOG.md
- docs/ROADMAP.md

## Delegation hints
- Architecture boundary: technical_director
- Game loop/mechanics: game_designer
- Gameplay implementation: gameplay_engineer
- Keyboard/gamepad/player slots: input_engineer
- Shared camera/collision: camera_physics_engineer
- Local join/UI feedback: ui_ux_engineer
- Reproduction/regression: qa_engineer
- Performance evidence: performance_engineer
- Windows build/release: build_release_engineer
- Final correctness review: code_reviewer
- Docs/devlog: documentation_agent
- Future mobile/mini-game/Steam porting: platform_porting_engineer

## Definition of done
A task is not done merely because code was edited. It should have:
- scoped implementation,
- relevant validation,
- no known console errors introduced,
- manual test instructions if needed,
- docs updated when required,
- a concise result summary with known issues.


## Core services after v0.1
The next foundation milestone is v0.2 Core Services & Settings Foundation.
Keep Settings, Persistence, Audio, Localization, Pause, Platform Capabilities, and Diagnostics outside Gameplay.

### Settings rules
- Settings UI is not the authority; SettingsService is.
- Define settings through registry/schema metadata.
- Support defaults, validation, persistence, reset, schema versioning, and migration.
- Separate working/preview values from committed persisted values.
- High-risk display changes must support confirmation/revert.
- Brightness means in-game gamma/exposure unless a platform-specific requirement says otherwise; do not change OS monitor brightness.
- Hide or disable unsupported settings through PlatformCapabilityService.
- Do not expose controls that have no real effect.
- P1/P2 bindings belong to input/settings boundaries, not Player gameplay code.
- Accessibility settings are first-class settings, not late-stage hacks.


## Runtime & Content Foundation after v0.2
The next milestone is v0.3 Runtime & Content Foundation.

### Runtime
- Centralize scene transitions in SceneFlowService once introduced.
- Separate AppState from scene asset names.
- Keep gameplay time, UI/unscaled time, and pause ownership explicit.
- Route gameplay randomness through a seeded RandomService once introduced.
- Feature flags are temporary experiments and need removal criteria.

### Save / data
- Never serialize Cocos Nodes or Components directly.
- Persist stable DTO/snapshot data with schemaVersion, validation, and migration.
- Keep Settings, permanent Profile, and temporary Run/Session state separate.
- Persistent content references use stable content IDs.

### Content / assets
- Prefer data-driven definitions for content that will be saved, referenced, tuned, or expanded.
- Stable IDs must not depend on display names, array positions, or prefab filenames.
- Validate duplicate/missing content IDs during development.
- Define dynamic asset ownership and release responsibility.
- Use Asset Bundles and pooling only when lifecycle, distribution, or performance evidence justifies them.

### UI / events
- Support controller-first UI navigation where practical.
- Use domain events for facts that happened; use direct service calls for explicit commands.
- Do not use Node as a global custom-event bus.
- Avoid a universal stringly-typed EventBus.

### Future-readiness
Do not implement networking, replay, rollback, universal stat/ability frameworks, or mod SDKs before needed. Preserve clean semantic input, time, random, content-ID, platform and presentation boundaries so those directions remain possible.


## Market-validated stop rule
The mandatory generic foundation ends at v0.5 Universal Gameplay Kernel.
After v0.5, prioritize playable greybox prototypes over further generic architecture.

Do not add Combat, Narrative, Mission, Quest, Roguelike, Economy, Crafting, Networking, Replay, Mod or other specialized frameworks merely because they may be useful later.

A specialized Gameplay Pack requires:
1. a chosen prototype/game direction,
2. a concrete current use case,
3. acceptance criteria,
4. use in the active prototype or Vertical Slice.

Priority:
FUN -> PLAYABLE -> ROBUST -> EXTENSIBLE -> ELEGANT.


## v5 authoritative product pillars
- The world is 3D.
- First playable form is two-player local multiplayer on Windows.
- Do not assume the players are cooperative; competitive and mixed games are valid.
- Final genre is intentionally undecided.
- Linear narrative is not a project constraint.
- Networking is deferred, but gameplay must not hardcode physical local input into Actor behavior.
- Primary external 3D asset discovery sources are Quaternius, Fab free content, and itch.io free content.
- The user owns visual/style approval; Codex owns technical asset processing and integration.

## Genre-neutral rule
Before Game Direction Lock, do not introduce Fighting, Racing, Management, Narrative, Combat, Roguelike, Sports, Simulation or other specialized frameworks into Core unless required by an active prototype.

Prefer:
InputSource -> Semantic Command -> Actor

Avoid:
Keyboard/Gamepad -> genre-specific Player code

The generic foundation ends at v0.5 Universal Gameplay Kernel.
