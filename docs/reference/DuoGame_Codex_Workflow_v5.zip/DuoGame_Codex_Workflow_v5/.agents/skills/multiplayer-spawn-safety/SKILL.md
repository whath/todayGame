---
name: multiplayer-spawn-safety
description: Use for safe local-coop spawn/respawn placement, collision checks and fallback positions.
---

# Rule
Use this workflow only for its scoped purpose. Keep changes minimal, validate the active prototype need, and do not broaden into unrelated framework work.
